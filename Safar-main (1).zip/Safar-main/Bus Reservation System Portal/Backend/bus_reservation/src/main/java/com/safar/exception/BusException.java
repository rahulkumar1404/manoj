package com.safar.exception;

public class BusException extends Exception{
    public BusException(){}
    public BusException(String msg){super(msg);}
}
