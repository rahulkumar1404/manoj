// console.log("Hello");
// name="Manoj";
// console.log(name);
// var name = "mirge";
// console.log(name);

// let name="Manoj";
// console.log(name);

// let name = "Mirge";
// name="Mirge";
// console.log(name);


// const name="Manoj";
// const surname= "Mirge"
// console.log(name);
// let name;
// console.log(name);

// const name;
// console.log([name,surname]);

// let phoneNUmber = BigInt(987656543212);
// console.log(phoneNUmber);

// let bd = Symbol("B-ve");
// console.log(bd);

// const obje = {
//     name:"Manoj",
//     age:22,
//     phoneNumber:BigInt(9087654432),
//     bg:Symbol("B+ve")
// };

// console.log(obje);

// console.log(obje.name);
// console.log(obje["name"]);


// const number = "22";

// console.log(typeof number);

// const nuValue = Number(number);
// console.log(nuValue);
// console.log(typeof nuValue);

// console.log(typeof null);

// const age =  function(){
//     console.log(18);
// } ;

// console.log(age());

// let number = new Number(32415265642);

// console.log(number.toFixed(1));

// console.log(number.toPrecision(3));


// let age = 20;

// if(age<20){
//     console.log("smaller");
// }else if(age==20){
//     console.log("Equals 20");
// }else{
//     console.log("greater");
// }

// switch (age){
//     case 1 : console.log(1);
//     break;
//     case 20 : console.log(20);
//     break;
//     default: {
//         console.log("Default");
//     };
// }


// for(let i=0;i<10;i++){
//     console.log(i);
// }

// let i=0;

// while(i<10){
//     console.log(i++);
// }

// let i=0;

// do{
//     console.log(i++);
// }while(i<0);


// const arr = [9,8,7,6,5,4];

// for(let i in arr){
//     console.log(arr[i]);
// }


// const info = {  
//     name:"Manoj",
//     age:22,
//     honest:true,
//     phoneNumber: BigInt(90765433),
//     bg:Symbol("B+ve")    

// };


// for(let i in info){
//     console.log(info[i]);
// }


// const name = "Manoj";

// for(let i of name){
//     console.log(i);
// }


// let college = "      JV Mehata       " ;

// console.log(college);

// console.log(college.length);

// for(let i=0;i<college.length;i++){
//     console.log(college[i]);
// }

// let trimmed = college.trim();

// console.log(trimmed);

// console.log(trimmed.toUpperCase());

// console.log(trimmed.toLowerCase());

// console.log(trimmed.slice(2,trimmed.length-2));

// let name = "Manoj";
// let surname = "Mirge";

// console.log(name.concat(surname));

// let ans = `ans is ${3+2}`;

// console.log(ans);

// console.log(ans.indexOf("n"));

// console.log(trimmed.substring(2,trimmed.length));

// console.log(trimmed);

// console.log(trimmed.includes("JV"));



//  num = [9,8,7,6,5,4];


//  num2 = [3,2,1];

// num.concat(num2);

// console.log(num);



// num.unshift(10);

// console.log(num);

// let last = num.shift();
// console.log(last);

// console.log(num);


// console.log(num);

// console.log(num.toString());

// for(let i=0;i<num.length;i++){
//     console.log(num[i]);
// }

// num.push(10);
// console.log(num);

// let last = num.pop();

// console.log(last);

// console.log(num);

// let num = [9,8,7,6];
// let num2 = [5,4,3];

// let num3 = num.concat(num2);

// console.log(num3);

// console.log(num.indexOf(9));

// console.log(num.lastIndexOf(3));



// function print(a){
//     for(let i=0;i<a;i++){
//         console.log(i);
//     }
// };

// print(10);


// const print = (a) => {
//     for(let i=0;i<a;i++){
//         console.log(i);
//     }
// };


// print(10);

// (function(){
//     for(let i=0;i<10;i++){
//         console.log(i)
//     }
// })();


// let arr = [9,8,7,6,5,4,3];

// arr.forEach((i)=>console.log(i));

// let ans = arr.map((i)=>i*2);

// console.log(ans);


// let ans = arr.filter(i => i%2==0);


// console.log(ans);

// let ans = Math.abs(-4);

// console.log(ans);


// let ans = Math.round(4.5);

// console.log(ans);
// console.log(" Ceil ",Math.ceil(ans));
// console.log(" Floor ",Math.floor(ans));


// console.log(Math.max());
// console.log(Math.min());

// for(let i=0;i<10;i++){
//     console.log(Math.round(Math.random()*(100-1+1)+1));
// }

// let date = new Date();

// console.log("UTC String",date.toUTCString());
// console.log("STRING",date.toString());
// console.log(date.getUTCHours());
// console.log(date.getHours());

// console.log(date.toString(YYYY-MM-DD,{MM:dd}))


// const arr = [9,7,5,4];
// const arr2 = [4,3,2,1,[11,22,33]];


// const arr4 = arr.concat(arr2).flat();

// console.log(arr4);

// console.log(Array.isArray(arr));

// let arr = Array.from("12345");
// let arr = Array.of(1,2,3,4,5);
// console.log(arr);

// let ans = Symbol("B+ve");

// let obj = {
//     name:"Manoj",
//     age:22,
//     phoneNumber:BigInt(9021342135),
//     [ans]:"KuchBhi"
// };

// for(let i in obj){
//     console.log(typeof i);
// }


// class ans {
//     name="Manoj";
//     ans="DOne";
// };


// let obj = new ans();
// Object.freeze(ans);
// obj.ans="Done";

// console.log(obj);\


// let obj = {
//     name : () => console.log("Hello")
// };

// obj.name();

// let obj2 = {
//     obj : "ans"
// }

// let obj = {
//     obji: obj2  
// }


// console.log(typeof obj?.obji);

// let obj = {
//     name:"Manoj",
//     address : {
//         street:"Wadi"
//     },
//     surname:"Mirge"
// }


// console.log(address);

// console.log(obj.constructor())

// let obj2 ={
//     name2:"Manoj",
//     surname2:"Mirge"
// }

// let obj3 = Object.assign({},obj,obj2);

// console.log(obj);
// console.log(obj3);

// let obj3 = {...obj,...obj2};

// console.log(obj3);

// let arr = Object.values(obj3);

// console.log(arr);



// let ans = function (i=3){
//     for(let j=0;j<i;j++){
//         console.log(j);
//     }
// }

// ans(5);

// addTwo(5,10);

// function addTwo(a,b)
//     (console.log(a+b))


// (function(a,b){
//     console.log(a+b);
// })(10,12);











