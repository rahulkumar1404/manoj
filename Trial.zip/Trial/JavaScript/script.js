// let div1 = document.querySelector("#dv1");

// div1.style.backgroundColor="grey";
// div1.style.color="white";

// let div2 = document.querySelector("#dv2");
// div2.style.backgroundColor="red";
// div2.style.color="white";

// let el = document.createElement("p");
// el.innerText="para 3";
// el.style.backgroundColor="brown";
// el.style.color="white";

// document.querySelector("#dv3").append(el);


// let btn1 = document.querySelector("#btn1");
// btn1.onclick = () => {
//     console.log("Button was Clicked!")
// }

// let btn2 = document.querySelector("#btn2");

// // btn2.ondblclick = () => {
// //     console.log("Doubled Clicked !");
// // }

// const handler1 = (evt) => {
//     console.log(evt.type);
// }

// const handler2 = () => {
//     console.log("Clicked !");
// }

// btn1.onclick = (evt) =>{
//     console.log(evt);
//     console.log(evt.type);
// }

// btn2.addEventListener("click",handler1);
// btn2.addEventListener("click",handler2);
// btn2.removeEventListener("click",handler1);

// let btn1 = document.querySelector("#btn1");

// let bd = document.querySelector("body");

// let currentMode = "light";

// const colorChange = () => {
//     if(currentMode==="light"){
//         currentMode = "dark"
//         bd.style.backgroundColor="black";
//     }else{
//         currentMode = "light"
//         bd.style.backgroundColor="white";
//     }

// }

// btn1.addEventListener("click",colorChange);
 

let btn1 = document.querySelector("#btn1");
let bd = document.querySelector("body");
let currentMode="light";

const changeMode = () =>{
    if(currentMode=="light"){
        currentMode="dark";
        bd.classList.add("dark");
        bd.classList.remove("light");
    }else{
        currentMode="light";
        bd.classList.add("light");
        bd.classList.remove("dark");
    }
}


btn1.addEventListener("click",changeMode);