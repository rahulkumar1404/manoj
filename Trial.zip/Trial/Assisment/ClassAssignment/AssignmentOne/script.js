let data = "Secrate INfo";

class User {
    constructor(name,email){
        this.name=name;
        this.email=email;
    }

    viewData(){
        console.log("Data ",data);
    }
}

class Admin extends User{
    constructor(name,email){
        super(name,email);
    }
    editData(){
        data="New data";
    }
}


let u1 = new User("Manoj","mirge@123.com");
console.log(u1);

let a1 = new Admin("Manoj","mirge@123.com");
console.log(a1);