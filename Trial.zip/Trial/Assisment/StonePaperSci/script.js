let userScore=0;
let compScore=0;

const choices = document.querySelectorAll(".choice");

const genComputerChoice = () =>{
    const option = ["rock","paper","sci"];
    const randomIndex =  Math.floor(Math.random()*3);
    return option[randomIndex];
};


choices.forEach((choice) =>{
    choice.addEventListener("click",()=>{
        let idValue = choice.getAttribute("id");
        playGame(idValue)
    })
});


const showWinner = (userWin) =>{
    if(userWin){
        console.log("You win");
    }else{
        console.log("You lose");
    }
}

const playGame = (idValue) =>{
    console.log("User Choice : ",idValue);
    const compChoice = genComputerChoice();
    console.log("Comp Choice : ",compChoice);

    if(idValue==compChoice){
        drawGame();
    }else{
        let userWin = true;
        if(idValue == "rock"){
            userWin = compChoice ==="paper"?false:true;
        }else if (idValue == "paper"){
            userWin = compChoice ==="sci"?false:true;
        }else{
            userWin = compChoice ==="rock"?false:true;
        }
        

        showWinner(userWin);
    }
    
};

const drawGame = () =>{
    console.log("The game was a draw");
}