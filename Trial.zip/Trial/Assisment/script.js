let bd = document.querySelector("body");

let el = document.createElement("button");
el.innerText="Click Me!";
el.style.backgroundColor="red";
el.style.color="white";

bd.prepend(el);